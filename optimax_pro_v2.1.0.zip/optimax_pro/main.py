#!/usr/bin/env python3
"""
Optimax Pro - Утилита оптимизации системы Windows
Автор: Optimax Team
Версия: 2.1.0
"""

import sys
import os

# Добавляем текущую папку в путь поиска модулей
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon
from ui.main_window import OptimaxPro

def main():
    """Главная функция запуска приложения"""
    try:
        # Создаем приложение
        app = QApplication(sys.argv)
        app.setApplicationName("Optimax Pro")
        app.setApplicationVersion("2.1.0")
        app.setOrganizationName("Optimax Team")

        # Устанавливаем высокое DPI
        app.setAttribute(Qt.ApplicationAttribute.AA_EnableHighDpiScaling, True)
        app.setAttribute(Qt.ApplicationAttribute.AA_UseHighDpiPixmaps, True)

        # Создаем главное окно
        window = OptimaxPro()
        window.show()

        # Запускаем приложение
        sys.exit(app.exec())

    except Exception as e:
        print(f"Ошибка запуска: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
